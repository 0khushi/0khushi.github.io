# Coursera-WebDev-JHU-Assignments

###HTML, CSS, JavaScript for Web Developers
####Johns Hopkins University
#####Coursera
<hr>
This repository contains my solutions to the Module - 2 and Module - 3 Coding Assignments for the course HTML, CSS, JavaScript for Web Developers by Johns Hopkins University on Coursera. <br>

<hr>
<b>Assignment Links:</b> <br>
- [Module 2 Assignment](http://goo.gl/4Blt4G)<br>
- [Module 3 Assignment](http://bit.ly/1mKZzJ5)<br>
Mockup illustrations are present in the Assignment documents.
<br>

<b>Solution Links:</b> <br>
- [Module 2 Solution](http://faheemzunjani.github.io/Coursera-WebDev-JHU-Assignments/module-2-solution/index.html) <br>
- [Module 3 Solution](http://faheemzunjani.github.io/Coursera-WebDev-JHU-Assignments/module-3-solution/index.html) <br>
